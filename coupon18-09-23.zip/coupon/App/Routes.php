<?php

namespace App;
use \App\Controllers;

if( ! defined('ABSPATH') ) exit();

class Routes
{
   
   private static $urlcoupon;
   private static $enqueue;
   private static $checkcoupon;

   public function __construct()
   {
      self::$urlcoupon = empty( self::$urlcoupon ) ? new \App\Controllers\Urlcoupon() : self::$urlcoupon;
      self::$enqueue = empty( self::$enqueue ) ? new \App\Controllers\Enqueue() : self::$enqueue;
      self::$checkcoupon = empty( self::$checkcoupon ) ? new \App\Controllers\Checkcoupon() : self::$checkcoupon;
   }

   public function AddActions()
   {    
       add_action( 'init', array( self::$checkcoupon, 'check_and_add_coupon_to_cart' ) );
       add_action( 'woocommerce_coupon_options', array( self::$urlcoupon, 'custom_coupon_field' ) );
       add_action( 'woocommerce_coupon_options_save', array( self::$urlcoupon, 'save_custom_coupon_field' ) );
       add_action( 'woocommerce_coupon_options_usage_restriction', array( self::$urlcoupon, 'add_custom_select_box' ) );
       add_filter( 'woocommerce_coupon_is_valid', array( self::$checkcoupon, 'get_coupon_include_user_roles_on_add_to_cart'), 10, 2);
       add_action( 'woocommerce_applied_coupon', array( self::$checkcoupon, 'run_function_after_coupon_applied') );
       add_action( 'woocommerce_before_calculate_totals', array( self::$checkcoupon, 'action_woocommerce_before_calculate_totals'), 10, 1 );
       add_filter( 'woocommerce_coupon_data_tabs', array( self::$urlcoupon, 'custom_coupon_data_tabs') );
       add_action( 'woocommerce_coupon_data_panels', array( self::$urlcoupon, 'custom_coupon_data_panel') );
       add_action( 'admin_enqueue_scripts',array( self::$enqueue, 'EnqueueList'));
       add_action( 'woocommerce_removed_coupon', array( self::$checkcoupon, 'get_removed_coupon_code'), 10, 1);
       
   }

}

?>